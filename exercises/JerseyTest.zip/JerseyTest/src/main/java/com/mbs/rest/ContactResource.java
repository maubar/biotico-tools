package com.mbs.rest;

import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
/**
 *
 * @author maubar
 */
@Path("/contacts")
public class ContactResource {
    
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Response getContacts(@PathParam("contact_id")String id){
        String contactList = "<contacts>" +
                "<contact id='1'><name>John Doe</name><uri>http://localhost:8080/JerseyTest/rest/contacts/1</uri></contact>" +
                "<contact id='2'><name>Jane Doe</name><uri>http://localhost:8080/JerseyTest/rest/contacts/2</uri></contact>" +
                "</contacts>";     
        return Response.status(200).entity(contactList).build();
    }
    
    @GET
    @Path("/{contact_id}")
    @Produces(MediaType.APPLICATION_XML)
    public Response getContact(@PathParam("contact_id")String id){
        Response resp = Response.status(404).build();
        String contact = "";
        if("1".equals(id)){
            contact = "<contact><name>John Doe</name><phone>1234-5678</phone></contact>";
            resp = Response.status(200).entity(contact).build();
        }
        else if ("2".equals(id)){
            contact = "<contact><name>Jane Dow</name><phone>9876-5432</phone></contact>";
            resp = Response.status(200).entity(contact).build();
        }
        return resp;
    }
    
}
